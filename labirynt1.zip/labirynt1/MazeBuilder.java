// MazeBuilder.java
package labirynt1;

import java.awt.Image;

public interface MazeBuilder {

    void buildMaze(); 
    
    void buildDoor(int roomNr1, int roomNr2);

    void buildRoom(int number, int x, int y);
    
    Maze getMaze(); 
    
}


//metoda buildMaze tworzy labirynt, czyli jest to rozpoczecie budowania nowego labiryntu
//
//metoda buildDoor powinna dzialac na zasadzie ze  przekazujemy jej informacje o numerze dwoch pokoi pomiedzy 
//ktorymi maja zostac utworzone. zakladamy ze dwa pokoje sasiaduja ze soba, jezeli nie sasiaduja to bedzie to nieprawidlowe. 
//powinien dzialac na zasadzie klasy Door.java
//
//metoda buildRoom   tworzy pokoj skladajacy sie z 4 scian, o podanym numerze w podanym polozeniu x i y
//
//metoda Maze getMaze() zwraca gotowy produkt