// ConcreteBuilder.java
package labirynt1;

import java.util.HashMap;
import java.util.Map;

public class ConcreteBuilder implements MazeBuilder {
    private final Maze maze;
    private final Map<Integer, Room> roomMap;

    public ConcreteBuilder() {
        this.maze = new Maze();
        this.roomMap = new HashMap<>();
    }

    @Override
    public void buildMaze() {
        for (int i = 1; i <= 3; i++) {
            buildRoom(i, i * 50, i * 50); // Przykładowa inicjalizacja trzech pokoi
        }

        buildDoor(1, 2); // Przykładowe dodanie drzwi między pokojem 1 a 2
        buildDoor(2, 3); // Przykładowe dodanie drzwi między pokojem 2 a 3
    }

    @Override
    public void buildDoor(int roomNr1, int roomNr2) {
        Room room1 = roomMap.get(roomNr1);
        Room room2 = roomMap.get(roomNr2);

        if (room1 != null && room2 != null) {
            Direction direction = determineDirection(room1, room2);

            if (direction != null) {
                Door door = new Door(direction);
                room1.setSide(direction, door);
                room2.setSide(direction.opposite(), door);
            } else {
                System.out.println("Nieprawidłowe pokoje. Pokoje nie sąsiadują ze sobą.");
            }
        } else {
            System.out.println("Nieprawidłowe numery pokoi.");
        }
    }

    @Override
    public void buildRoom(int number, int x, int y) {
        Room room = new Room(number, x, y);
        roomMap.put(number, room);
        maze.addRoom(room);

        // Dodajemy ściany do pokoju
        for (Direction direction : Direction.values()) {
            room.setSide(direction, new Wall(direction));
        }
    }

    @Override
    public Maze getMaze() {
        return maze;
    }

    private Direction determineDirection(Room room1, Room room2) {
        if (room1.getX() == room2.getX() && Math.abs(room1.getY() - room2.getY()) == 50) {
            return room1.getY() < room2.getY() ? Direction.SOUTH : Direction.NORTH;
        } else if (room1.getY() == room2.getY() && Math.abs(room1.getX() - room2.getX()) == 50) {
            return room1.getX() < room2.getX() ? Direction.EAST : Direction.WEST;
        }
        return null;
    }
}
