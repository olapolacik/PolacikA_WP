package labirynt1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

public class Wall extends MapSite {

    private Direction direction;

    public Wall(Direction direction) {
        this.direction = direction;
    }

    @Override
    public void enter() {
        // Implementacja, co się dzieje, gdy użytkownik próbuje wejść na ścianę
    }

    public Direction getDirection() {
        return direction;
    }

    @Override
    public void draw(Image image, int x, int y) {
        Graphics g = image.getGraphics();
        g.setColor(Color.black);

        switch (direction) {
            case NORTH:
                g.drawLine(x, y, x + MapSite.LENGTH, y);
                break;
            case EAST:
                g.drawLine(x + MapSite.LENGTH, y, x + MapSite.LENGTH, y + MapSite.LENGTH);
                break;
            case SOUTH:
                g.drawLine(x, y + MapSite.LENGTH, x + MapSite.LENGTH, y +MapSite.LENGTH);
                break;
            case WEST:
                g.drawLine(x, y, x, y + MapSite.LENGTH);
                break;
        }
    }
}
