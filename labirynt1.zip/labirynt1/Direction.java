// Direction.java
package labirynt1;

public enum Direction {
    NORTH {
        @Override
        public Direction opposite() {
            return SOUTH;
        }
    },
    EAST {
        @Override
        public Direction opposite() {
            return WEST;
        }
    },
    SOUTH {
        @Override
        public Direction opposite() {
            return NORTH;
        }
    },
    WEST {
        @Override
        public Direction opposite() {
            return EAST;
        }
    };

    public abstract Direction opposite();
}

