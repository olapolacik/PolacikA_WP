/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package labirynt1;

import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author Ola
 */

public class NewJFrame extends javax.swing.JFrame {

    public NewJFrame() {
        initComponents();
        drawPanel = (NewJPanel) jPanel;
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new NewJPanel();
        bStart = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 306, Short.MAX_VALUE)
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        bStart.setText("Start");
        bStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bStartActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(bStart)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(bStart)
                .addContainerGap(234, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bStartActionPerformed

   
Image image = drawPanel.getImage();
    int x = 0;
    int y = 0;

    // false = ściana
    // true = drzwi

    // r1
    boolean b[] = {false, true, false, false};
    Room r1 = new Room(x, y, b);
    x += MapSite.LENGTH;

    // r2
    b[0] = false;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r2 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
    // r3
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = true;
    Room r3 = new Room(x, y, b);
    y += MapSite.LENGTH;
    
    // r4
    b[0] = true;
    b[1] = true;
    b[2] = true;
    b[3] = false;
    Room r4 = new Room(x, y, b);
    x += MapSite.LENGTH;

    
    // r5
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = true;
    Room r5 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
    // r6
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = false;
    Room r6 = new Room(x, y, b);
    y += MapSite.LENGTH;

    // r7
    b[0] = true;
    b[1] = false;
    b[2] = true;
    b[3] = true;
    Room r7 = new Room(x, y, b);
    x -= MapSite.LENGTH;
    //y += MapSite.LENGTH;

    // r8
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r8 = new Room(x, y, b);
    x -= MapSite.LENGTH;
    
    // r9
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r9 = new Room(x, y, b);
    x -= MapSite.LENGTH;
    
    // r10
    b[0] = false;
    b[1] = true;
    b[2] = true;
    b[3] = false;
    Room r10 = new Room(x, y, b);
    x -= MapSite.LENGTH;
    
    // r11
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = false;
    Room r11 = new Room(x, y, b);
    y += MapSite.LENGTH;
    
    // r12
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = false;
    Room r12 = new Room(x, y, b);
    x += MapSite.LENGTH;

    // r13
    b[0] = true;
    b[1] = false;
    b[2] = true;
    b[3] = true;
    Room r13 = new Room(x, y, b);
    //x -= MapSite.LENGTH;
    y += MapSite.LENGTH;

    // r14
    b[0] = true;
    b[1] = false;
    b[2] = true;
    b[3] = false;
    Room r14 = new Room(x, y, b);
    //x += MapSite.LENGTH;
    y += MapSite.LENGTH;
    
    // r15
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r15 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
    // r16
    b[0] = false;
    b[1] = false;
    b[2] = false;
    b[3] = true;
    Room r16 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
    // r17
    b[0] = false;
    b[1] = true;
    b[2] = false;
    b[3] = false;
    Room r17 = new Room(x, y, b);
    x += MapSite.LENGTH;

    // r18
    b[0] = false;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r18 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
        // r19
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = true;
    Room r19 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
        // r20
    b[0] = true;
    b[1] = false;
    b[2] = false;
    b[3] = true;
    Room r20 = new Room(x, y, b);
    y -= MapSite.LENGTH;
    //x -= MapSite.LENGTH;

        // r21
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = false;
    Room r21 = new Room(x, y, b);
    x -= MapSite.LENGTH; 
    //y -= MapSite.LENGTH;
       
        // r22
    b[0] = false;
    b[1] = false;
    b[2] = true;
    b[3] = true;
    Room r22 = new Room(x, y, b);
    x -= MapSite.LENGTH; 
    //y -= MapSite.LENGTH;
    
        // r23
    b[0] = true;
    b[1] = true;
    b[2] = false;
    b[3] = false;
    Room r23 = new Room(x, y, b);
    //x -= MapSite.LENGTH; 
    y -= MapSite.LENGTH;
    
        // r24
    b[0] = true;
    b[1] = true;
    b[2] = true;
    b[3] = false;
    Room r24 = new Room(x, y, b);
    x += MapSite.LENGTH;
    
        // r25
    b[0] = true;
    b[1] = false;
    b[2] = false;
    b[3] = true;
    Room r25 = new Room(x, y, b);
    x += MapSite.LENGTH; 
    y -= MapSite.LENGTH;
    
        // r26
    b[0] = false;
    b[1] = false;
    b[2] = false;
    b[3] = true;
    Room r26 = new Room(x, y, b);
    x -= MapSite.LENGTH; 
    
        // r27
    b[0] = false;
    b[1] = true;
    b[2] = true;
    b[3] = false;
    Room r27 = new Room(x, y, b);
    x -= MapSite.LENGTH; 



    r1.draw(image);
    r2.draw(image);
    r3.draw(image);
    r4.draw(image);
    r5.draw(image);
    r6.draw(image);
    r7.draw(image);
    r8.draw(image);
    r9.draw(image);
    r10.draw(image);
    r11.draw(image);
    r12.draw(image);
    r13.draw(image);
    r14.draw(image);
    r15.draw(image);
    r16.draw(image);
    r17.draw(image);
    r18.draw(image);
    r19.draw(image);
    r20.draw(image);
    r21.draw(image);
    r22.draw(image);
    r23.draw(image);
    r24.draw(image);
    r25.draw(image);
    r26.draw(image);
    r27.draw(image);


    drawPanel.repaint();
        
    }//GEN-LAST:event_bStartActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    } 
    
    private NewJPanel drawPanel;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bStart;
    private javax.swing.JPanel jPanel;
    // End of variables declaration//GEN-END:variables
}
