package labirynt1;

import java.awt.Image;

public class Room extends MapSite {

    private MapSite[] sides = new MapSite[4];
    private int x;
    private int y;
    private static int roomCount = 0;
    private int roomNumber;

    public Room(int x, int y, boolean[] door) {
        roomCount++;
        this.roomNumber = roomCount;
        this.x = x;
        this.y = y;
        Direction[] d = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

        for (int i = 0; i < 4; i++) {
            if (door[i]) {
                this.sides[i] = new Door(d[i]);
            } else {
                this.sides[i] = new Wall(d[i]);
            }
        }
    }

    public void draw(Image image) {
        for (int i = 0; i < 4; i++) {
            this.sides[i].draw(image, this.x, this.y);
        }
    }

    public void draw(Image image, int x, int y) {
        this.draw(image);
    }

    public void enter() {
        System.out.println("Wchodzisz do pokoju " + roomNumber);
    }

    public String getDirection() {
        return "Wchodzisz do pokoju " + roomNumber;
    }

    public int getRoomNumber() {
        return roomNumber;
    }
}
