
package labirynt1;

public class Main {
    public static void main(String[] args) {
        // Tworzenie kilku pokoi
//        Room room1 = new Room(1, 60, 60);
//        Room room2 = new Room(2, 100, 60);
//        Room room3 = new Room(3, 60, 100);
//
//        // Tworzenie labiryntu

//        Maze maze = new Maze(0, 60, 60);
//        maze.addRoom(room1);
//        maze.addRoom(room2);
//        maze.addRoom(room3);


    }
}
