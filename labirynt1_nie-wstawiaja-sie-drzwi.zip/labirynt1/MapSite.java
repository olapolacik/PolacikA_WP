package labirynt1;

import java.awt.Image;

public abstract class MapSite {
    public static final int LENGTH = 50;
    protected Direction direction;

    public abstract void draw(Image image, int x, int y);

    public Direction getDirection() {
        return direction;
    }
}
