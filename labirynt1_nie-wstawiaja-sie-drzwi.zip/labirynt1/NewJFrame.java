/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package labirynt1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.Stack;


public class NewJFrame extends javax.swing.JFrame {
    private Room[][] lab;
    private boolean[][] l;
    private Direction currentDirection;


    public NewJFrame() {
        initComponents();
        drawPanel = (NewJPanel) jPanel;
        
        
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel = new NewJPanel();
        bStart = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanelLayout = new javax.swing.GroupLayout(jPanel);
        jPanel.setLayout(jPanelLayout);
        jPanelLayout.setHorizontalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 539, Short.MAX_VALUE)
        );
        jPanelLayout.setVerticalGroup(
            jPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        bStart.setText("Start");
        bStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bStartActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(bStart)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(bStart)
                .addContainerGap(462, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bStartActionPerformed

        Image image = drawPanel.getImage();


        // Clear the existing maze
        Graphics g = image.getGraphics();
        g.clearRect(0, 0, image.getWidth(null), image.getHeight(null));

        // Initialize lab and l
        lab = new Room[10][10];
        l = new boolean[10][10];

        // Check if lab and l are properly initialized (add this part)
        if (lab == null || l == null) {
            System.out.println("lab or l is not properly initialized");
            return;
        }

        drawRoomNumbers(image);

        // Generate a new maze
        build(10, 10, 70, image);

        drawPanel.repaint();
    }

    private void drawRoomNumbers(Image img) {
        Graphics g = img.getGraphics();
        Font font = new Font("Arial", Font.BOLD, 12); // You can adjust the font as needed
        g.setFont(font);

        for (int i = 0; i < lab.length; i++) {
            for (int j = 0; j < lab[i].length; j++) {
                if (l[i][j]) {
                    // Calculate the center coordinates of the room
                    int centerX = MapSite.LENGTH * j + MapSite.LENGTH / 2;
                    int centerY = MapSite.LENGTH * i + MapSite.LENGTH / 2;

                    // Draw room number in the center
                    g.setColor(Color.BLACK);  // Set color to black
                    g.drawString(Integer.toString(lab[i][j].getRoomNumber()), centerX, centerY);
                }
            }
        }
    }


    
    
    
    
    
public void build(int sz, int wy, int po, Image img) {
    // Inicjalizacja labiryntu
    lab = new Room[wy][sz];
    l = new boolean[wy][sz];

    for (int i = 0; i < wy; i++) {
        for (int j = 0; j < sz; j++) {
            lab[i][j] = new Room(MapSite.LENGTH * j, MapSite.LENGTH * i, new boolean[4]);
            l[i][j] = false;
        }
    }

    Stack<Room> stack = new Stack<>();
    Random random = new Random();

    // Utwórz stos i dodaj pierwszy pokój
    stack.push(lab[0][0]);

    int roomNumber = 1;

    while (!stack.isEmpty()) {
        Room currentRoom = stack.pop();
        int x = currentRoom.getX() / MapSite.LENGTH;
        int y = currentRoom.getY() / MapSite.LENGTH;

        if (!l[y][x]) {
            l[y][x] = true;
            currentRoom.setRoomNumber(roomNumber++);

            // Wybierz losowo kierunek
            Direction[] directions = Direction.values();
            List<Direction> unvisitedNeighbors = new ArrayList<>();

            for (Direction direction : directions) {
                int newX = x + direction.dx;
                int newY = y + direction.dy;

                if (newX >= 0 && newX < sz && newY >= 0 && newY < wy && !l[newY][newX]) {
                    unvisitedNeighbors.add(direction);
                }
            }

            if (!unvisitedNeighbors.isEmpty()) {
                // Wybierz losowego nieodwiedzonego sąsiada
                Direction randomDirection = unvisitedNeighbors.get(random.nextInt(unvisitedNeighbors.size()));

                // Usuń ścianę między aktualnym pokojem a sąsiadem
                currentRoom.addDoor(randomDirection);

                // Przesuń się do sąsiada
                int newX = x + randomDirection.dx;
                int newY = y + randomDirection.dy;
                stack.push(lab[newY][newX]);
            }
        }
    }

    // Rysuj pokoje
    for (int i = 0; i < wy; i++) {
        for (int j = 0; j < sz; j++) {
            if (l[i][j]) {
                if (i > 0 && !l[i - 1][j]) lab[i][j].setWall(Direction.NORTH);
                if (j < sz - 1 && !l[i][j + 1]) lab[i][j].setWall(Direction.EAST);
                if (i < wy - 1 && !l[i + 1][j]) lab[i][j].setWall(Direction.SOUTH);
                if (j > 0 && !l[i][j - 1]) lab[i][j].setWall(Direction.WEST);
                lab[i][j].draw(img);
            }
        }
    }

    // Dodaj rysowanie numerów pokojów
    drawRoomNumbers(img);
}







    
    

 
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
        
        
        
    } 
    
    private NewJPanel drawPanel;
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bStart;
    private javax.swing.JPanel jPanel;
    // End of variables declaration//GEN-END:variables
}
