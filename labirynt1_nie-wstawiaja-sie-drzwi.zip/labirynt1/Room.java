package labirynt1;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;

public class Room extends MapSite {
    
    private final MapSite[] sides = new MapSite[4];
    private final int x;
    private final int y;
    private static int roomCount = 0;
    private int roomNumber;
    private Direction currentDirection;

    public Room(int x, int y, boolean[] door) {
        roomCount++;
        this.roomNumber = roomCount;
        this.x = x;
        this.y = y;
        this.currentDirection = Direction.NORTH; // Domyślnie ustawiamy na NORTH

        Direction[] d = { Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST };

        for (int i = 0; i < 4; i++) {
            if (door[i]) {
                this.sides[i] = new Door(true, 0, d[i]);
            } else {
                this.sides[i] = new Wall(d[i]);
            }
        }
    }

    public void draw(Image image) {
        for (int i = 0; i < 4; i++) {
            this.sides[i].draw(image, this.x, this.y);
        }
        Graphics g = image.getGraphics();
        g.setColor(Color.green);
        g.drawLine(x, y, x + LENGTH, y + LENGTH);
    }

        public void setRoomNumber(int number) {
        this.roomNumber = number;
    }
    public void draw(Image image, int x, int y) {
        this.draw(image);
    }

    public void buildDoors(int sz, int wy) {
        Random random = new Random();

        for (int i = 0; i < 4; i++) {
            if (sides[i] instanceof Wall) {
                // Sprawdź, czy można wstawić drzwi w danym kierunku
                int newX = x / MapSite.LENGTH + Direction.values()[i].dx;
                int newY = y / MapSite.LENGTH + Direction.values()[i].dy;

                if (newX >= 0 && newX < sz && newY >= 0 && newY < wy && !hasDoor(Direction.values()[i])) {
                    // Jeśli tak, wstaw drzwi
                    sides[i] = new Door(true, 0, Direction.values()[i]);
                }
            }
        }
    }
    
    public void enter() {
        System.out.println("Wchodzisz do pokoju " + roomNumber);
    }
    
    public void addDoor(Direction direction) {
    for (int i = 0; i < 4; i++) {
        if (direction == sides[i].getDirection()) {
            sides[i] = new Door(true, 0, direction);
            break;
        }
    }
}
public boolean hasDoor(Direction direction) {
    for (int i = 0; i < 4; i++) {
        if (sides[i].getDirection() == direction && sides[i] instanceof Door) {
            return true;
        }
    }
    return false;
}


    public int getRoomNumber() {
        return roomNumber;
    }

    public void setWall(Direction k) {
        switch (k) {
            case NORTH:
                sides[0] = new Wall(k);
                break;
            case EAST:
                sides[1] = new Wall(k);
                break;
            case SOUTH:
                sides[2] = new Wall(k);
                break;
            case WEST:
                sides[3] = new Wall(k);
                break;
        }
    }

    public boolean isDoor(int i) {
        Door d = new Door();
        return d.getClass() == sides[i].getClass();
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public Direction getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(Direction direction) {
        this.currentDirection = direction;
    }
}
